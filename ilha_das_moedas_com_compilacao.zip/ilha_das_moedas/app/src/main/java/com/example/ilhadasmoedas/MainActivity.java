package com.example.ilhadasmoedas;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Random;
import java.util.Locale;

public class MainActivity extends Activity {
    SharedPreferences save;
    long coins = 5000;
    int spins = 25;
    int village = 1;
    int progress = 0;
    int shields = 3;
    TextView coinText, spinText, villageText, resultText, progressText, shieldText;
    TextView[] reels = new TextView[3];
    final String[] symbols = {"🍒", "💰", "🛡️", "⚔️", "⭐"};
    final Random random = new Random();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        save = getSharedPreferences("game", MODE_PRIVATE);
        coins = save.getLong("coins", 5000);
        spins = save.getInt("spins", 25);
        village = save.getInt("village", 1);
        progress = save.getInt("progress", 0);
        shields = save.getInt("shields", 3);
        buildUI();
        update();
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        return l;
    }
    LinearLayout.LayoutParams lp(int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(8, 7, 8, 7); return p;
    }
    Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(16); b.setBackground(bg(color, 24));
        return b;
    }
    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(245, 249, 230));
        LinearLayout root = column();
        root.setPadding(16, 20, 16, 24);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("🏝️ ILHA DAS MOEDAS", 27, Color.rgb(25, 91, 65));
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title, lp(-1, 52));
        root.addView(text("Sua ilha • jogo offline • progresso salvo no aparelho", 13, Color.DKGRAY), lp(-1, 32));

        LinearLayout stats = new LinearLayout(this);
        stats.setGravity(Gravity.CENTER);
        stats.setBackground(bg(Color.WHITE, 18));
        coinText = text("", 17, Color.rgb(155, 101, 0));
        spinText = text("", 17, Color.rgb(34, 90, 160));
        stats.addView(coinText, new LinearLayout.LayoutParams(0, 64, 1));
        stats.addView(spinText, new LinearLayout.LayoutParams(0, 64, 1));
        root.addView(stats, lp(-1, 68));

        villageText = text("", 22, Color.rgb(25, 91, 65));
        villageText.setTypeface(null, Typeface.BOLD);
        root.addView(villageText, lp(-1, 48));
        TextView island = text("🌴     🛖      🌴\n🏡    🏰    🏡\n🌊  🌊  🌊", 30, Color.rgb(25, 91, 65));
        island.setBackground(bg(Color.rgb(211, 239, 199), 22));
        root.addView(island, lp(-1, 150));
        progressText = text("", 15, Color.DKGRAY);
        root.addView(progressText, lp(-1, 35));

        root.addView(text("🎰 SUA MÁQUINA DE GIROS", 19, Color.rgb(25, 91, 65)), lp(-1, 42));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setBackground(bg(Color.rgb(255, 239, 180), 18));
        for (int i=0; i<3; i++) {
            reels[i] = text("❔", 36, Color.BLACK);
            row.addView(reels[i], new LinearLayout.LayoutParams(0, 80, 1));
        }
        root.addView(row, lp(-1, 90));
        resultText = text("Gire para ganhar moedas!", 16, Color.rgb(80, 70, 40));
        root.addView(resultText, lp(-1, 40));
        Button spin = button("GIRAR (1 giro)", Color.rgb(225, 126, 27));
        root.addView(spin, lp(-1, 56));
        spin.setOnClickListener(v -> spin());

        Button free = button("🎁 Receber 10 giros grátis", Color.rgb(36, 137, 93));
        root.addView(free, lp(-1, 52));
        free.setOnClickListener(v -> { spins += 10; resultText.setText("Você recebeu 10 giros!"); update(); });

        shieldText = text("", 15, Color.DKGRAY);
        root.addView(shieldText, lp(-1, 30));
        Button shield = button("🛡️ Recuperar escudos (500 moedas)", Color.rgb(63, 113, 168));
        root.addView(shield, lp(-1, 52));
        shield.setOnClickListener(v -> {
            if (coins >= 500) { coins -= 500; shields = Math.min(3, shields + 1); resultText.setText("Escudo recuperado!"); }
            else resultText.setText("Você precisa de mais moedas.");
            update();
        });

        Button build = button("🔨 Construir próximo marco (1.000 moedas)", Color.rgb(116, 77, 157));
        root.addView(build, lp(-1, 56));
        build.setOnClickListener(v -> {
            if (coins >= 1000) {
                coins -= 1000; progress++;
                if (progress >= 5) { village++; progress = 0; resultText.setText("🎉 Nova ilha desbloqueada!"); }
                else resultText.setText("Construção concluída! " + progress + "/5 marcos.");
            } else resultText.setText("Junte mais moedas para construir.");
            update();
        });

        Button raid = button("⚔️ Aventura solo (+ moedas)", Color.rgb(190, 65, 55));
        root.addView(raid, lp(-1, 52));
        raid.setOnClickListener(v -> {
            int gain = 200 + random.nextInt(801);
            coins += gain;
            resultText.setText("Aventura concluída! Você encontrou " + gain + " moedas.");
            update();
        });

        Button reset = button("Reiniciar progresso", Color.GRAY);
        root.addView(reset, lp(-1, 45));
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Reiniciar jogo?")
            .setMessage("Seu progresso local será apagado.")
            .setNegativeButton("Cancelar", (d,w)->{})
            .setPositiveButton("Reiniciar", (d,w)->{
                coins=5000; spins=25; village=1; progress=0; shields=3;
                for(TextView reel:reels) reel.setText("❔");
                resultText.setText("Novo jogo iniciado!");
                update();
            }).show());
        root.addView(text("Projeto independente de demonstração. Não é o Coin Master oficial.", 12, Color.GRAY), lp(-1, 45));
    }

    void spin() {
        if (spins <= 0) { resultText.setText("Sem giros! Pegue giros grátis abaixo."); return; }
        spins--;
        for (int i=0; i<3; i++) reels[i].setText(symbols[random.nextInt(symbols.length)]);
        String a=reels[0].getText().toString(), b=reels[1].getText().toString(), c=reels[2].getText().toString();
        if (a.equals(b) && b.equals(c)) {
            int gain = 1500;
            coins += gain; resultText.setText("🎉 TRINCA! +" + gain + " moedas!");
        } else if (a.equals(b) || b.equals(c) || a.equals(c)) {
            int gain = 350;
            coins += gain; resultText.setText("Boa! Dois símbolos iguais: +" + gain + " moedas.");
        } else if (a.contains("💰") || b.contains("💰") || c.contains("💰")) {
            coins += 100; resultText.setText("Você achou moedas! +100.");
        } else if (a.contains("🛡️") || b.contains("🛡️") || c.contains("🛡️")) {
            shields = Math.min(3, shields + 1); resultText.setText("Você ganhou um escudo!");
        } else if (a.contains("⚔️") || b.contains("⚔️") || c.contains("⚔️")) {
            int gain = 100 + random.nextInt(301);
            coins += gain; resultText.setText("Ataque simulado contra uma ilha fictícia! +" + gain + " moedas.");
        } else resultText.setText("Não foi dessa vez. Tente outro giro!");
        update();
    }

    void update() {
        coinText.setText("🪙 " + String.format(Locale.getDefault(), "%,d", coins));
        spinText.setText("🎰 " + spins + " giros");
        villageText.setText("🏝️ Ilha " + village);
        progressText.setText("Marcos construídos: " + progress + "/5");
        shieldText.setText("🛡️ Escudos: " + shields + "/3");
        save.edit().putLong("coins", coins).putInt("spins", spins)
            .putInt("village", village).putInt("progress", progress)
            .putInt("shields", shields).apply();
    }
}